/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 *
 * (c) 2011-2017 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
/* eslint indent: 0 */


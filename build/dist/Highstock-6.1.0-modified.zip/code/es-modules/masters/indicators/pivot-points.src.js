/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2017 Paweł Fus
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../indicators/pivot-points.src.js';

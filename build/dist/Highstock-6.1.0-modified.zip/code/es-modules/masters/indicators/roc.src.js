/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2017 Kacper Madej
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../indicators/roc.src.js';
